/* eslint-disable linebreak-style */
const express = require('express');

const router = express.Router();

const adminController = require('../controller/adminController');

router.get('/', adminController.adminAll);
router.get('/:adminId', adminController.adminSingle);
router.post('/add', adminController.adminAdd);
router.patch('/update/:adminId', adminController.adminUpdate);
router.delete('/del/:adminId', adminController.adminDelete);