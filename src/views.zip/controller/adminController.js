const debug = require('debug')('app:studentController');
const db = require('../../db');

exports.adminAll = function adminAll(req, res) {
  const sql = `select adminId, fname, mname, lname 
              FROM admins`;
  db.query(sql,
    (err, result) => {
      if (err) {
        return res.json(err);
      }
      return res.send(result);
    });
};

// single admin
exports.adminSingle = function adminSingle(req, res) {

}